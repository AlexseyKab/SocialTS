import React from "react";
import s from './Dialogs.module.css'


const Music = () =>{
    return (
        <div>
            Music
        </div>
    )
}

export default Music;