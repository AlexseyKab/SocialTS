import React from "react";
import s from './Dialogs.module.css'


const Settings = () =>{
    return (
        <div>
            Settings
        </div>
    )
}

export default Settings;