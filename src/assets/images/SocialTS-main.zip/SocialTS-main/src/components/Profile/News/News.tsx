import React from "react";
import s from './Dialogs.module.css'


const News = () =>{
    return (
        <div>
            News
        </div>
    )
}

export default News;